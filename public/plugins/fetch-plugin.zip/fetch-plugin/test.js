import { fetchFullPage } from "./index.js";
import readline from "readline";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.question("Enter the URL to fetch: ", async (url) => {
  try {
    const html = await fetchFullPage(url);
    console.log(html); // nicely formatted HTML
  } catch (err) {
    console.error("Error fetching URL:", err.message);
  } finally {
    rl.close();
  }
});
