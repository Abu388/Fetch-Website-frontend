import fetch from "node-fetch";
import prettier from "prettier";

export async function fetchFullPage(url, options = {}) {
  if (!url) throw new Error("URL is required");

  try {
    const response = await fetch(url, options);
    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);

    const html = await response.text();

    // Format HTML nicely
    const prettyHTML = prettier.format(html, { parser: "html" });

    return prettyHTML; // return the well-structured HTML
  } catch (error) {
    console.error("Fetch error:", error.message);
    throw error;
  }
}
